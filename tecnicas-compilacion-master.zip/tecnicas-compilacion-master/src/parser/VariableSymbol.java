package parser;

public class VariableSymbol extends Symbol {
    public VariableSymbol(String id, String dt, boolean init, boolean used) {
        super(id, dt, init, used);
    }
}
