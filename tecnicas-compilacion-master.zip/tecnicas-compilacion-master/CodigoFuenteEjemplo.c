int main() {
    int c = 2, d, e = 3, h;
}